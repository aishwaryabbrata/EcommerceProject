package com.iblamefashionstore.fabindia.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.iblamefashionstore.fabindia.model.Category;
import com.iblamefashionstore.fabindia.model.Product;
import com.iblamefashionstore.fabindia.service.CategoryService;
import com.iblamefashionstore.fabindia.service.ProductService;


@Controller
public class ProductController<CategoryBean> {
	
	@Autowired	(required=true)
	private ProductService productService;


		
		
		
		

		@RequestMapping(value = "/products", method = RequestMethod.GET)
		public String listCategorys(Model model) {
			model.addAttribute("product", new Product());
			model.addAttribute("productList", this.productService.list());
			return "product";
		}
		
		public ProductService getProductService() {
			return productService;
		}

		public void setProductService(ProductService productService) {
			this.productService = productService;
		}

			//For add and update category both
			@RequestMapping(value= "/product/add", method = RequestMethod.POST)
			public String addProduct(@ModelAttribute("product") Product product){
				
			
					productService.saveOrUpdate(product);
				
				return "redirect:/products";
				
			}
			@RequestMapping("product/remove/{id}")
		    public String removeProduct(@PathVariable("id") String id,ModelMap model) throws Exception{
				
		       try {
				productService.delete(id);
				model.addAttribute("message","Successfully Added");
			} catch (Exception e) {
				model.addAttribute("message",e.getMessage());
				e.printStackTrace();
			}
		       //redirectAttrs.addFlashAttribute(arg0, arg1)
		        return "redirect:/products";
		    }
		 
		    @RequestMapping("product/edit/{id}")
		    public String editCategory(@PathVariable("id") String id, Model model){
		    	System.out.println("editProduct");
		        model.addAttribute("product", this.productService.get(id));
		        model.addAttribute("listProducts", this.productService.list());
		        return "product";
		    }

}
