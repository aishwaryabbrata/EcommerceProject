package com.iblamefashionstore.fabindia.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.iblamefashionstore.fabindia.dao.CategoryDAOImpl;
import com.iblamefashionstore.fabindia.model.Category;

@Service
@Transactional
public class CategoryService {
	@Autowired(required=true)
	private CategoryDAOImpl categoryDAO;

	public CategoryDAOImpl getCategoryDAO() {
		return categoryDAO;
	}

	public void setCategoryDAO(CategoryDAOImpl categoryDAO) {
		this.categoryDAO = categoryDAO;
	}
	
	public List<Category> list() {
		return categoryDAO.list();
	}
	
	public void saveOrUpdate(Category category) {
		categoryDAO.saveOrUpdate(category);
	}
	
	public void delete(String id) {
		categoryDAO.delete(id);
	}
	
	public Category get(String id) {
		return categoryDAO.get(id);
	}

}
