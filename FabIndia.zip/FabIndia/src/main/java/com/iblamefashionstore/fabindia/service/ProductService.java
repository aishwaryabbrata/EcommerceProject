package com.iblamefashionstore.fabindia.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.iblamefashionstore.fabindia.dao.ProductDAOImpl;
import com.iblamefashionstore.fabindia.model.Product;


@Service
@Transactional
public class ProductService {

	@Autowired(required=true)
	private ProductDAOImpl productDAO;

	public ProductDAOImpl getProductDAO() {
		return productDAO;
	}

	public void setProductDAO(ProductDAOImpl productDAO) {
		this.productDAO = productDAO;
	}
	
	public List<Product> list() {
		return productDAO.list();
	}
	
	public void saveOrUpdate(Product product) {
		productDAO.saveOrUpdate(product);
	}
	
	public void delete(String id) {
		productDAO.delete(id);
	}
	
	public Product get(String id) {
		return productDAO.get(id);
	}

}
